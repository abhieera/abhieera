A Pen created at CodePen.io. You can find this one at https://codepen.io/pandey47/pen/myrPoj.

 A Little birthday card I hacked together in an afternoon for my sister's birthday. Uses 3D transforms and such, and a bit of shitty JS for opening and closing the card.

Forked from [Michael Duerinckx](http://codepen.io/michd/)'s Pen [3D birthday card](http://codepen.io/michd/pen/gxFmf/).